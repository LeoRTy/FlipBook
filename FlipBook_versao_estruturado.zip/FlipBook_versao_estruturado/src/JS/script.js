// Lista de imagens do catálogo
const imagens = [
  "./src/imagens/capa.jpg",
  
  "./src/imagens/img01.jpg",
  "./src/imagens/img02.jpg",
  "./src/imagens/img03.jpg",
  "./src/imagens/img04.jpg",

  "./src/imagens/fim.jpg"
];


///////////////////
//    SCRIPT     //
///////////////////

const bookElement = document.getElementById("book");

let pageFlip = null; // guarda a instância do flipbook (desktop)

// Renderiza mobile: imagens empilhadas com espaçamento
function renderMobile() {
  // destrói flipbook se existir
  if (pageFlip && typeof pageFlip.destroy === "function") {
    pageFlip.destroy();
  }
  pageFlip = null;

  // limpa e injeta as imagens
  bookElement.innerHTML = "";
  imagens.forEach(src => {
    const img = document.createElement("img");
    img.src = src;
    img.alt = "";
    img.style.width = "100%";
    img.style.height = "auto";
    img.style.display = "block";
    img.style.marginBottom = "5px";
    bookElement.appendChild(img);
  });

  // remove funções globais dos botões (não são usadas no mobile)
  delete window.next;
  delete window.prev;
  delete window.goToFirst;
  delete window.goToLast;
  delete window.toggleFullscreen;
}

// Renderiza desktop: flipbook com botões
function renderDesktop() {
  // limpa container
  bookElement.innerHTML = "";

  pageFlip = new St.PageFlip(bookElement, {
    width: 595,           // base A4 (uma página)
    height: 842,
    size: "stretch",      // adapta ao container
    minWidth: 800,        // garante 2 páginas no desktop
    minHeight: 420,
    maxWidth: 2000,
    maxHeight: 2600,
    drawShadow: true,
    flippingTime: 800,
    showCover: true,      // capa sozinha
    useMouseEvents: true,
    mobileScrollSupport: false,
    usePortrait: false    // evita modo 1 página no desktop
  });

  pageFlip.loadFromImages(imagens);

  // Funções de controle (expostas globalmente pros botões)
  function next() { pageFlip.flipNext(); }
  function prev() { pageFlip.flipPrev(); }
  function goToFirst() { pageFlip.flip(0); }
  function goToLast() { pageFlip.flip(imagens.length - 1); }
  function toggleFullscreen() {
    const viewer = document.getElementById("viewer");
    if (!document.fullscreenElement) {
      viewer.requestFullscreen().catch(err => alert(`Erro ao ativar fullscreen: ${err.message}`));
    } else {
      document.exitFullscreen();
    }
  }

  window.next = next;
  window.prev = prev;
  window.goToFirst = goToFirst;
  window.goToLast = goToLast;
  window.toggleFullscreen = toggleFullscreen;

  // Atalhos de teclado (desktop)
  document.onkeydown = (e) => {
    switch (e.key) {
      case "ArrowRight": next(); break;
      case "ArrowLeft":  prev(); break;
      case "Home":       goToFirst(); break;
      case "End":        goToLast(); break;
      case "Escape":
        if (document.fullscreenElement) document.exitFullscreen();
        break;
    }
  };
}

// Aplica modo conforme largura (somente resolução, como você pediu)
const mql = window.matchMedia("(max-width: 768px)");

function applyMode(isMobile) {
  if (isMobile) renderMobile();
  else renderDesktop();
}

// Primeira renderização
applyMode(mql.matches);

// Reage a mudanças de tamanho (gira tela, ajusta DevTools, etc.)
if (mql.addEventListener) {
  mql.addEventListener("change", e => applyMode(e.matches));
} else {
  
  // fallback para navegadores antigos
  mql.addListener(e => applyMode(e.matches));
}